package com.riktheguy.qrattendance;

public class DatabaseConnection {

    static final String BASEURL="http://theguysite.000webhostapp.com/";
    static final String PRESENTURL="present.php?";
    static final String ATTENDANCE="getAttendance.php?";
    static final String GETSTUDENT="getStudent.php";
    static final String UPDATE="update.php?";
    static final String LOGIN="login.php?";
    static final String ADD="addStudent.php?";


}
