package com.riktheguy.qrattendance;

public class StudentItem {

    public String id;
    public String name;

    public StudentItem(String id, String name){
        this.id = id;
        this.name=name;
    }
}
